neu nhu e la con mo , moi ngay a mo
